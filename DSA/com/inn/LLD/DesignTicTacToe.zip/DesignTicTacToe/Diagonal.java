package com.inn.LLD.DesignTicTacToe;

public class Diagonal implements WinStrategy{

    private static Diagonal instance=null;

    private Diagonal () {
    }

    public static Diagonal getInstance() {
        if(instance == null) {
            instance = new Diagonal();
        }
        return instance;
    }

    @Override
    public boolean checkWin(Board board, Player player) {
        char symbol = player.getSymbol();
        char[][] ticTacToeBoard = board.getBoard();
        int size = ticTacToeBoard.length;
        if((ticTacToeBoard[0][0] == symbol && ticTacToeBoard[1][1] == symbol && ticTacToeBoard[size-1][size-1] == symbol) ||
           (ticTacToeBoard[0][size-1] == symbol && ticTacToeBoard[1][size-2] == symbol && ticTacToeBoard[size-1][0] == symbol)) {
            return true;
        }
        return false;
    }

}
