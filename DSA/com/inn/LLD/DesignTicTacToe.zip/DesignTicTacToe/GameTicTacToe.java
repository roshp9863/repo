package com.inn.LLD.DesignTicTacToe;

import java.util.List;
import java.util.Scanner;

public class GameTicTacToe {

    List<WinStrategy> winStrategy;
    private boolean isWin = false;
    private boolean isDraw = false;
    private Board board ;
    private List<Player> players;

    GameTicTacToe(Admin admin) {
        this.board = admin.getBoard();
        this.players = admin.getPlayers();
        this.winStrategy = admin.getWinStrategy();
        
        
    }     
    
    public void play() {
        int currentPlayerIndex = 0;
        Player currentPlayer = players.get(currentPlayerIndex);
        while(!isDraw && !isWin) {
            board.displayBoard();
            System.out.println(currentPlayer.getName() + "'s turn. Enter row and column:");
            Scanner sc = new Scanner(System.in);
            int row = sc.nextInt();
            int col = sc.nextInt();
            if(board.getBoard()[row][col] != '.') {
                System.out.println("Cell already occupied! Try again.");
                continue;
            }
            board.setBoard(row, col, currentPlayer.getSymbol());
            for(WinStrategy strategy : winStrategy) {
                if(strategy.checkWin(board, currentPlayer)) {
                    isWin = true;
                    System.out.println(currentPlayer.getName() + " wins!");
                    board.displayBoard();
                    return;
                }
            }
            if(board.isBoardFull()) {
                isDraw = true;
                System.out.println("It's a draw!");
                board.displayBoard();
                return;
            }
            currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
            currentPlayer = players.get(currentPlayerIndex);       
        }    
            
    }
}
