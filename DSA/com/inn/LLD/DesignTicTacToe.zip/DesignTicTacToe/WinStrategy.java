package com.inn.LLD.DesignTicTacToe;

public interface WinStrategy {
    boolean checkWin(Board board, Player player);
    
}
