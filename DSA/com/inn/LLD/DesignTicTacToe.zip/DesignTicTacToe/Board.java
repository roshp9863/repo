package com.inn.LLD.DesignTicTacToe;

public class Board {
    char[][] board;
    private int size;
    public Board(int size) {
        this.size = size;
        board = new char[size][size];
    }
    public char[][] getBoard() {
        return board;
    }
    public void displayBoard() {
        for(int i=0; i<size; i++) {
            for(int j=0; j<size; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void setBoard(int row, int col, char symbol) {
        board[row][col] = symbol;
    }

    public boolean isBoardFull() {
        for(int i=0; i<size; i++) {
            for(int j=0; j<size; j++) {
                if(board[i][j] == '.') {
                    return false;
                }
            }
        }
        return true;
    }
    
}
