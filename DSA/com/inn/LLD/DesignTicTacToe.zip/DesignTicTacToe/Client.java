package com.inn.LLD.DesignTicTacToe;


public class Client {

    public static void main(String[] args) {
        Admin admin = new Admin(3, 2);
        GameTicTacToe game = new GameTicTacToe(admin);
        game.play();
    }

}
