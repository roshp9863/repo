package com.inn.LLD.DesignPen;

public class BallPen extends RefillPens  {


    public BallPen(String name, int price, String brand, ClosingMechanism closingType) {
        super(name, price, brand, PenType.BALL_POINT, closingType);
    }


    @Override
    public void write() {
        System.out.println("Writing with ball pen with price : " + getPrice());
    }


    @Override
    public void refill() {
        System.out.println("Refilling the ball pen");
    }


}
