package com.inn.LLD.DesignPen;

public interface ClosingMechanism {

    void open();
    void close();

    
} 
