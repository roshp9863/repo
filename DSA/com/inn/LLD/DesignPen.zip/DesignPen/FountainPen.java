package com.inn.LLD.DesignPen;

public class FountainPen extends Pen {

    public FountainPen(String name, int price, String brand, ClickStrategy closingType) {
        super(name, price+25, brand, PenType.FOUNTAIN, closingType);
    }

    @Override
    public void write() {
        System.out.println("Writing with fountain pen with price : " + getPrice());
    }

}
