// package com.inn.LLD.DesignPen;

// public enum ClosingType {
//     CAP, CLICK, TWIST
// }
