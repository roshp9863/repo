package com.inn.LLD.DesignPen;

public enum PenType {
    BALL_POINT, GEL, FOUNTAIN
}
