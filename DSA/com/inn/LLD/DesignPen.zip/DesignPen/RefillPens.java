package com.inn.LLD.DesignPen;

public abstract class RefillPens extends Pen implements Refillable {

    public RefillPens(String name, int price, String brand, PenType penType, ClosingMechanism closingType) {
        super(name, price, brand, penType, closingType);
    }
    
    public abstract void refill();
    
    
}
