package com.inn.LLD.DesignPen;


public class GelPen extends RefillPens  {


    public GelPen(String name, int price, String brand, ClosingMechanism closingMechanism) {
        super(name, price + 10, brand, PenType.GEL, closingMechanism);
    }


    @Override
    public void write() {
        System.out.println("Writing with gel pen with price : " + getPrice() );
    }


    @Override
    public void refill() {
        System.out.println("Refilling the gel pen");
    }



}
