package com.inn.LLD.DesignPen;

public class Client {
    public static void main(String[] args) {
        Pen pen = new FountainPen("Fountain Pen", 100, "Parker", new ClickStrategy());
        pen.write();
        pen.getClosingType().open();
        pen.getClosingType().close();

        RefillPens pen1 = new BallPen("Ball Point Pen", 50, "Reynolds", new TwistStrategy());
        pen1.write();
        pen1.refill();
        pen1.getClosingType().open();
        pen1.getClosingType().close();

        pen1 = new GelPen("Gel Pen", 70, "Pilot", new CapStrategy());
        pen1.write();
        pen1.refill(); 
        pen1.getClosingType().open();
        pen1.getClosingType().close();
    }

}
