package com.inn.LLD.DesignPen;

public interface Refillable {

}
